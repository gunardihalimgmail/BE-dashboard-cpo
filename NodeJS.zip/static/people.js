const peoples = ['yoshi','ryu','chun-li','mario']
const ages = [20, 25, 30, 35]

// console.log(peoples)
module.exports = {
    peoples,
    ages
}


// other alternative
exports.peoples = peoples
// exports.ages = ages