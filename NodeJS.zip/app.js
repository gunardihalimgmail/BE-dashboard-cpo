const express = require('express');
const querystring = require('querystring');
const url = require('url');
const path = require('path');
const { peoples, ages } = require('./static/people');
const { getData_SQL_Await, getData_SQL} = require('./static/koneksi');
const port = process.env.PORT || 3007;

// const sql = require('mssql')
// const sql = require('mssql/msnodesqlv8')      // LOCALHOST

// KONEKSI SQL SERVER AUTHENTICATION (BY PASSWORD)
const sqlConfig_Server = {
    user: process.env.DB_USER || 'loginiot',
    password: process.env.DB_PWD || '!otTIS88jkT',
    database: process.env.DB_NAME || 'IOT',
    server: '192.168.1.120',
    // pool: {
    //   max: 10,
    //   min: 0,
    //   idleTimeoutMillis: 30000
    // },
    options: {
      encrypt: false, // for azure  (di false-kan untuk bisa connect ke 192.168.1.120)
      trustServerCertificate: false // change to true for local dev / self-signed certs
    }
}

const app = express();

app.get('/volume',(req,res)=>{

    setTimeout(()=>{
        let tangki = req?.['query']?.['tangki'];
    
        res.setHeader("Content-Type","application/json")
        res.setHeader('Access-Control-Allow-Origin','*')
    
        if (typeof tangki != 'undefined' && tangki != null)
        {
            if (tangki < 1 || tangki > 4){
                res.status(404).send({
                    statusCode: 404,
                    message:'Tangki ' + tangki + ' Not Found'
                })
                return
            }
            else{
                getData_SQL_Await('SELECT * FROM dbo.Ms_Volume_Tangki WHERE tangki = \'' + tangki + '\'').then(result=>{
                    res.status(200).send(result)
                })
            }
        }
        else{
            getData_SQL_Await('SELECT * FROM dbo.Ms_Volume_Tangki').then(result=>{
                res.status(200).send(result)
            })
        }
    },100)
})


// getData_SQL((res)=>{
//     console.log(res)
// })



// const conn = new sql.ConnectionPool({
//     database: "Inventory",
//     server: "(localdb)\MSSQLLocalDB",
//     driver: "msnodesqlv8",
//     options:{
//         trustedConnection: true
//     }
// })

// sample 1
// const sqlConfig_local = {
//     driver:"SQL Server",
//     server:".\\SQLEXPRESS",
//     database: "IOT_MS",
//     options:{
//         trustedConnection:true
//     }
//     // trusted_connection:true
// }

// sample 2
// var config = {
//     connectionString: 'Driver=SQL Server; server=.\\SQLEXPRESS;Database=Student;Trusted_Connection=true;'
//   };

// sql.connect(sqlConfig_local, err => {
//     new sql.Request().query('SELECT top 5 * from dbo.Ms_Volume_Tangki', (err, results) => {

//         // console.log(".:The Good Place:.");

//         if(err) { // SQL error, but connection OK.
//             console.log("==== Error ==== : "+ err);
//         } else { // All is rosey in your garden.
//             console.dir(results?.['recordset'])
//             for (let [i, v] of results?.['recordset'].entries()){
//                 console.dir('Tangki : ' + v?.['tangki'] + ', Tinggi : ' + v?.['tinggi'] +  ', Volume : ' + v?.['volume']);
//             }

//         };
//     })
// })
  


// sql.connect(sqlConfig).then(()=>{
//     // return sql.query("select * from dbo.devices")
//     return sql.query("select * from dbo.devices")
// }).then(results=>{
//     console.log("=== DEVICES ===")
//     for (let [i, v] of results?.['recordset'].entries())
//     {
//         console.log("ID DEVICE : ", v?.['id_device'], " at index : ", i)
//     }
    
//     // sql.query("select * from dbo.users")
//     //         .then((res)=>{
//     //             console.log("=== USERNAME ===")
//     //             for (let [i, v] of res?.['recordset'].entries())
//     //             {
//     //                 console.log("USERNAME : ", v?.['username'], " at index : ", i)
//     //             }
//     //         })
// }).catch(err=>{
//     console.log("ERROR")
// })

// sql.connect(sqlConfig).then(()=>{
//     return sql.query("select * from dbo.users")
// }).then(results=>{
//     console.log("=== USERS ===");
//     for (let [i, v] of results?.['recordset'].entries())
//     {
//         console.log("USERNAME : ", v?.['username'], " at index : ", i)
//     }
// })

// console.dir(results?.['recordset'])
    


// async () => {
//     try {
//         // await sql.connect('Server=192.168.1.120,1433; Database=IOT; User Id=loginiot;password=!otTIS88jkT;Encrypt=true')
//         await sql.connect(sqlConfig)
//         const result = await sql.query`select * from dbo.devices where id=3`
//         console.log("result")
//         console.log(result)
//     }catch(err){
//         console.log("ERROR")
//     }
// }

// app.listen(3007);
// app.use(express.static(path.join(__dirname,'public')))

app.listen(port, ()=>{
    console.log("Server is listening from Express to 3007")
    // console.log(__dirname)
    // console.log(__filename)
});

// for not caching, always not modified
app.disable('etag');


// app.get('/', (req, res) => {
    
    // res.send('Hello this is \'Index\'')
    // res.setHeader('Content-Type','application/json')
    // res.setHeader('Access-Control-Allow-Origin','*')
    // res.status(200).send({nama:'james', umur: 37})

    // res.redirect('/about')
    // res.sendFile('./views/tes.html', {root: __dirname})
// })


// app.get('/about', (req, res) => {
    // let query_umur = req.query.umur
    // if (typeof query_umur != 'undefined'){
    //     res.send('Hello this is \'About\' WITH UMUR : ' + query_umur)
    // }else{
    //     res.send('Hello this is \'About\'')
    // }
    
    // let rawUrl = 'https://stackabuse.com?page=2&limit=3'
    // let parsedUrl = url.parse(rawUrl)
    // let parsedQs = querystring.parse(parsedUrl.query)
    // // console.log(parsedQs)
// })

// app.get('/about/:id', (req, res) => {
//     let param_id = req.params.id
//     res.send('Hello this is \'About\' WITH ID : ' + param_id)
// })

app.use((req,res)=>{
    // res.status(404).send('<h1 style = "color:red">This is ERROR 404</h1>')
    res.status(404).send(
        {
            statusCode: 404,
            message:'Not Found'
        }
    )
})