const { peoples, ages } = require('./static/people')

console.log(peoples)
console.log(ages)

const os = require('os')
console.log(os.version())
console.log(os.platform())
console.log(os.homedir())
console.log(os.hostname())
// console.log(people.peoples)
// console.log(people.ages)
// console.log(people.peoples, people.ages)